import pygame

class Player:
	position = pygame.Vector2()
	velocity = pygame.Vector2()
	rect = pygame.Rect(position, (30,200))

class Player2:
	position = pygame.Vector2()
	velocity = pygame.Vector2()
	rect = pygame.Rect(position, (30,200))
