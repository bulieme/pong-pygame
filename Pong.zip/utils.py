def sec2mil(sec):
	return int(sec*1000)